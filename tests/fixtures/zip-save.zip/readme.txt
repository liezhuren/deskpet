﻿plain note
